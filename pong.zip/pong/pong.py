import pygame
import sys

# Initialiser Pygame
pygame.init()

# Définir les dimensions de la fenêtre
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Pong")

# Couleurs
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

# Raquettes et balle
PADDLE_WIDTH, PADDLE_HEIGHT = 10, 100
BALL_SIZE = 20

# Positions initiales
paddle1_pos = [10, HEIGHT//2 - PADDLE_HEIGHT//2]
paddle2_pos = [WIDTH - 20, HEIGHT//2 - PADDLE_HEIGHT//2]
ball_pos = [WIDTH//2, HEIGHT//2]

# Vitesse des raquettes et de la balle
paddle_speed = 10
ball_speed = [5, 5]

# Scores
score1, score2 = 0, 0

# Police pour afficher le score
font = pygame.font.Font(None, 74)

# Boucle principale du jeu
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Gestion des entrées clavier pour les raquettes
    keys = pygame.key.get_pressed()
    if keys[pygame.K_w] and paddle1_pos[1] > 0:
        paddle1_pos[1] -= paddle_speed
    if keys[pygame.K_s] and paddle1_pos[1] < HEIGHT - PADDLE_HEIGHT:
        paddle1_pos[1] += paddle_speed
    if keys[pygame.K_UP] and paddle2_pos[1] > 0:
        paddle2_pos[1] -= paddle_speed
    if keys[pygame.K_DOWN] and paddle2_pos[1] < HEIGHT - PADDLE_HEIGHT:
        paddle2_pos[1] += paddle_speed

    # Déplacer la balle
    ball_pos[0] += ball_speed[0]
    ball_pos[1] += ball_speed[1]

    # Collision avec le haut et le bas de l'écran
    if ball_pos[1] <= 0 or ball_pos[1] >= HEIGHT - BALL_SIZE:
        ball_speed[1] = -ball_speed[1]

    # Collision avec les raquettes
    if (ball_pos[0] <= paddle1_pos[0] + PADDLE_WIDTH and
            paddle1_pos[1] < ball_pos[1] < paddle1_pos[1] + PADDLE_HEIGHT) or \
       (ball_pos[0] >= paddle2_pos[0] - BALL_SIZE and
            paddle2_pos[1] < ball_pos[1] < paddle2_pos[1] + PADDLE_HEIGHT):
        ball_speed[0] = -ball_speed[0]

    # Vérification des points
    if ball_pos[0] <= 0:
        score2 += 1
        ball_pos = [WIDTH//2, HEIGHT//2]
        ball_speed = [5, 5]
    if ball_pos[0] >= WIDTH - BALL_SIZE:
        score1 += 1
        ball_pos = [WIDTH//2, HEIGHT//2]
        ball_speed = [-5, -5]

    # Affichage de l'écran
    screen.fill(BLACK)
    pygame.draw.rect(screen, WHITE, (*paddle1_pos, PADDLE_WIDTH, PADDLE_HEIGHT))
    pygame.draw.rect(screen, WHITE, (*paddle2_pos, PADDLE_WIDTH, PADDLE_HEIGHT))
    pygame.draw.ellipse(screen, WHITE, (*ball_pos, BALL_SIZE, BALL_SIZE))

    # Affichage des scores
    score_text = font.render(f"{score1}   {score2}", True, WHITE)
    screen.blit(score_text, (WIDTH//2 - score_text.get_width()//2, 10))

    # Mettre à jour l'affichage
    pygame.display.flip()

    # Limiter la vitesse de la boucle
    pygame.time.Clock().tick(60)

pygame.quit()
sys.exit()
